1. Please use the Main class's main method to run the program. 
Note: The main program will change everyweek as we introduce more features in the project.