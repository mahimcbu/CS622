1. Please use the Main class's main method to run the program. 
2. Run phiTest junit test class for testing
3. Run HealtDAtaMetricsTest for junit testing of the file reader
4. The generic T used in User extends HealthData<?> to make sure it only accepts HEalthDAta type.


Note: The main class creates the user, user health info that will be user input later.
Note: The main program will change every week as we introduce more features to the project.