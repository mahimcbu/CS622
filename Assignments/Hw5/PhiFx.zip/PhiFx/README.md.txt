1. Please use the Main class's main method to run the program. 
2. There are Junit test files for a few important classes and methods
3 I implemented JavaFX in this iteration. Follow this link in order to run JavaFX in eclipse. 
https://openjfx.io/openjfx-docs/
4. I haven't implemented user log in yet as I am waiting for the database connectivity. 

How to use the GUI:

5. click create user and input fields to create a user. Only email and password are validated as of now. 
6. password must be 8 chars, minimum of one uppercase, number, special char. 


Once I have database connectivity, everything else in the app should work properly.

Note: The main class creates the user, and user health info that will be user input later.
Note: The main program will change every week as we introduce more features to the project.