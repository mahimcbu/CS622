1. Please use the Main class's main method to run the program. 
2. There are Junit test files for a few important classes and methods
3 I implemented JavaFX in this iteration. Follow this link in order to run JavaFX in eclipse. 
https://openjfx.io/openjfx-docs/
4. Please set up sqlLIte(youtube) for your IDE and computer, make sure to run the database setup class first to create the tables.
5. Note the name of the db is "healthtracker.db" you cna change the name as you wish.

How to use the GUI:

1. create a user
2. you can start recording your health data from then on. 
3. if you close the app, login with the user email and password and you will get the access to your helathdata again. 
