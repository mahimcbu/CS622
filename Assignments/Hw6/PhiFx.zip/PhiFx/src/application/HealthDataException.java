package application;

public class HealthDataException extends Exception {
    public HealthDataException(String message) {
        super(message);
    }
}
