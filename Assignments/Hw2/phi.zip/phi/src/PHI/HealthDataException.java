package PHI;

public class HealthDataException extends Exception {
    public HealthDataException(String message) {
        super(message);
    }
}
